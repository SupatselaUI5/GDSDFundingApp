sap.ui.define([
	"./BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/Device"
	// "sap/ui/core/mvc/Controller"
], function(BaseController, Filter, FilterOperator, MessageBox, Device) {
	"use strict";
	return BaseController.extend("gdsd.FundingApplication.controller.NewApplication", {

		onInit: function() {
			//	this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._mViewSettingsDialogs = {};
			//this.Router = this.getRouter();
			//hook into route matched to adopt parameters for UI rendering
			//this.Router.getRoute("NewApplication").attachPatternMatched(this._onObjectMatched, this);
			//this.Router().getRoute("NewApplication").attachPatternMatched(this._onObjectMatched, this);

			//get the odata model from the component
			this._oODataModel = this.getOwnerComponent().getModel();

			//Get Application Data
			this.getApplicationData();

		},

		_onObjectMatched: function() {

		},

		getApplicationData: function() {

			sap.ui.core.BusyIndicator.show(0);

			//get the BP data for the current logged in user
			//var userId = sap.ushell.Container.getService("UserInfo").getId();

			var oFilter = new sap.ui.model.Filter("BpNo", "EQ", '1600000202');

			this._oODataModel.read("/GETApplicationFundingSet", {
				//				filters: [oFilter],
				success: function(odata) {
					if (odata.results[0]) {
						var ApplicationJsonModel = new sap.ui.model.json.JSONModel({
							data: odata.results[0]
						});

						//Set Binding Mode
						ApplicationJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

						this.byId("detailPage").setTitle(odata.results[0].But000.McName1);
						if (odata.results[0].Statu.Status === "I1002") {
							this.byId("Status").setText(odata.results[0].Statu.Txt30);
							this.byId("Status").setState("Success");
						} else {
							this.byId("Status").setText(odata.results[0].Statu.Txt30);
							this.byId("Status").setState("Error");
						}

						this.byId("BankName").setValue(odata.results[0].BankingName.BankName);

						if (odata.results[0].Banking.BankType === "01") {
							this.byId("BankType").setValue("Current Account");
						} else if (odata.results[0].Banking.BankType === "02") {
							this.byId("BankType").setValue("Savings Account");
						} else if (odata.results[0].Banking.BankType === "03") {
							this.byId("BankType").setValue("Loan Account");
						} else if (odata.results[0].Banking.BankType === "04") {
							this.byId("BankType").setValue("General Ledger");
						}
					}

					//	this.byId("btnSubmit").setVisible(false);

					this.byId("headerNPO").setModel(ApplicationJsonModel);
					this.byId("headerNPO").bindElement({
						path: "/data"
					});

					this.byId("formOrg").setModel(ApplicationJsonModel);
					this.byId("formOrg").bindElement({
						path: "/data"
					});

					this.byId("formAdrc").setModel(ApplicationJsonModel);
					this.byId("formAdrc").bindElement({
						path: "/data"
					});

					this.byId("formContacts").setModel(ApplicationJsonModel);
					this.byId("formContacts").bindElement({
						path: "/data"
					});

					this.byId("formBank").setModel(ApplicationJsonModel);
					this.byId("formBank").bindElement({
						path: "/data"
					});

					this.byId("formApplication").setModel(ApplicationJsonModel);
					this.byId("formApplication").bindElement({
						path: "/data"
					});

					this.byId("formViability").setModel(ApplicationJsonModel);
					this.byId("formViability").bindElement({
						path: "/data"
					});

					this.byId("formCost").setModel(ApplicationJsonModel);
					this.byId("formCost").bindElement({
						path: "/data"
					});

					this.byId("formMonitorNPO").setModel(ApplicationJsonModel);
					this.byId("formMonitorNPO").bindElement({
						path: "/data"
					});

					this.byId("formCapacity").setModel(ApplicationJsonModel);
					this.byId("formCapacity").bindElement({
						path: "/data"
					});

					this.byId("formFundingReq").setModel(ApplicationJsonModel);
					this.byId("formFundingReq").bindElement({
						path: "/data"
					});

					this.byId("formAchievements").setModel(ApplicationJsonModel);
					this.byId("formAchievements").bindElement({
						path: "/data"
					});

					this.byId("formChallenges").setModel(ApplicationJsonModel);
					this.byId("formChallenges").bindElement({
						path: "/data"
					});

					this.byId("formNetworks").setModel(ApplicationJsonModel);
					this.byId("formNetworks").bindElement({
						path: "/data"
					});

					this.getView().setModel(ApplicationJsonModel);

					//ECM Intergration
					var SAPObj, ObjId;
					SAPObj = 'BUS2000270';
					ObjId = '0050569545C51EDB85F0B3462B7E511D';
					//destroy content on the attachment Icon Tab Filer 
					this.byId("WPFilter").destroyContent();
					//create an HTML object so that an iFrame can be added
					var html = new sap.ui.core.HTML();
					//adding a standard Fiori ECM application to the iframe and pass necessary url parameters 
					html.setContent("<div class='FrameWrapper'><iframe id='EcmFrame' src='/sap/bc/ui5_ui5/sap/zrmf_bws_ui/index.html?SAPObj=" +
						SAPObj +
						"&ObjId=" + ObjId + "' width='1200px' height='500px'></iframe></div>");
					//adding the html object to the Icon Tab filter
					this.byId("WPFilter").addContent(html);

					//this.onAddWorkSpace();
					this.getObjectives();
					//sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve application details");
				}.bind(this)
			});

		},

		createFormDialog: function(sDialogFragmentName) {

			// https://stackoverflow.com/questions/55667673/how-to-remove-duplicates-and-display-only-unique-values-in-viewsettingsitem
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

				if (Device.system.desktop) {
					oDialog.addStyleClass("sapUiSizeCompact");
				}
			}
			return oDialog;
		},

		onAddBeneficiariesPressed: function() {
			this.createFormDialog("gdsd.FundingApplication.Fragments.Beneficiaries").open();
		},
		onAddStaffCapacity: function() {
			this.createFormDialog("gdsd.FundingApplication.Fragments.CapacityofStaff").open();
		},

		onAddBoardCapacity: function() {
			this.createFormDialog("gdsd.FundingApplication.Fragments.CapacityofBoard").open();
		},

		onCancel: function() {
			//Cater for the age group selected 
			var oDialogKey,
				oDialogValue;

			for (oDialogKey in this._mViewSettingsDialogs) {
				oDialogValue = this._mViewSettingsDialogs[oDialogKey];

				if (oDialogValue) {
					oDialogValue.close();
					// oDialogValue = null;
				}
			}
		},

		onSaveBeneficiaries: function(oEvent) {
			var oTable = this.byId("beneficiaries");
			var columnListItemNewLine = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Text({
						text: sap.ui.getCore().byId("bname").getValue()
					}),
					new sap.m.Text({
						text: sap.ui.getCore().byId("bposition").getValue()
					}),
					new sap.m.Text({
						text: sap.ui.getCore().byId("bgender").getValue()
					})
				]
			});
			oTable.addItem(columnListItemNewLine);
			this.onCancel();
		},
		onSaveStaffCapacity: function(oEvent) {
			var oTable = this.byId("StaffCapacity");
			var columnListItemNewLine = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Text({
						text: sap.ui.getCore().byId("scname").getValue()
					}),
					new sap.m.Text({
						text: sap.ui.getCore().byId("scposition").getValue()
					}),
					new sap.m.Text({
						text: sap.ui.getCore().byId("scgender").getValue()
					})
				]
			});
			oTable.addItem(columnListItemNewLine);
			this.onCancel();
		},
		onSaveBoardCapacity: function(oEvent) {
			var oTable = this.byId("BoardCapacity");
			var columnListItemNewLine = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Text({
						text: sap.ui.getCore().byId("bcname").getValue()
					}),
					new sap.m.Text({
						text: sap.ui.getCore().byId("bcposition").getValue()
					}),
					new sap.m.Text({
						text: sap.ui.getCore().byId("bcgender").getValue()
					})
				]
			});
			oTable.addItem(columnListItemNewLine);
			this.onCancel();
		},

		onAddWorkSpace: function(SAPObj, ObjId) {
			//destroy content on the attachment Icon Tab Filer 
			this.byId("attachementsFilter").destroyContent();
			//create an HTML object so that an iFrame can be added
			var html = new sap.ui.core.HTML();
			//adding a standard Fiori ECM application to the iframe and pass necessary url parameters 
			html.setContent("<div class='FrameWrapper'><iframe id='EcmFrame' src='/sap/bc/ui5_ui5/sap/zrmf_bws_ui/index.html?SAPObj=" + SAPObj +
				"&ObjId=" + ObjId + "' width='1200px' height='500px'></iframe></div>");
			//adding the html object to the Icon Tab filter
			this.byId("attachementsFilter").addContent(html);
		},

		onNPONextPress: function() {
			// create a JSON Object to populate the data for when submitting the data 
			//there is currently no structure developed on the gateway for the create therefore the below structure is a dummy structure
			var oProperty = {};
			oProperty.Type = "";
			oProperty.Name = "";
			oProperty.PracticeNumber = "";
			//we submitting the auditing data in order to create the application on CRM so that the business workspace is created and pulled to the UI.
			this._oODataModel.create("/EntityName", oProperty, {
				success: function(data) {
					//parameters have to be returned when creating application
					this.objId = data.guid; //GUID number
					this.sabObj = // BUS2000125 we got this object ID from the ECM team
						this.onAddWorkSpace(this.sabObj, this.objId);

					this._oODataModel.read("/EntityName(GUID)", {
						success: function(odata) {
							//returns the structure of the newly created application which will be used on update
							this.createdApp = odata;
						}.bind(this)
					});
				}.bind(this),
				error: function(t) {
						this.getView().setBusy(false);
						this.onErrorMessageBoxPress(t, "Submitted");
					}
					.bind(this)
			});
		},

		getRouter: function() {
			return this.getOwnerComponent().getRouter();
		},

		getObjectives: function() {

			this._oODataModel.read("/GETObjectiveSet", {
				success: function(oData) {
					var ObjectivesJsonModel = new sap.ui.model.json.JSONModel({
						results: oData.results
					});
					this.getView().setModel(ObjectivesJsonModel, "ObjectivesModel");
					sap.ui.core.BusyIndicator.hide();

				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					//MessageBox.error("Error occured while retrieving Picklists");
				}.bind(this)
			});
		},

		onNpoNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDeteailsPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("npo");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDetailsNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("networks");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksNextPress: function() {
			this.byId("btnSubmit").setVisible(true);
			this.byId("IconBar").setSelectedKey("attachments");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsNextPress: function() {
			this.byId("IconBar").setSelectedKey("beneficiary");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsPrevPress: function() {
			this.byId("IconBar").setSelectedKey("particular");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onUpdate: function() {
			// this._oODataModel.update("/GETApplicationFundingSet('" + oPONumber + "')", oProperties, {
			var oProperties = this.getView().getModel().getData().data;
			this._oODataModel.update("/GETApplicationFundingSet(BpNo='" + oProperties.BpNo + "',Guid='" + oProperties.Guid + "',ObjectId='" +
				oProperties.ObjectId + "')", oProperties, {

					success: function(results) {

					},
					error: function(results) {

					}

				});
		},

		onSubmit: function() {
			this._aContexts = [];
			var row = this.getView().getModel().getData().data;
			var oContext = this._oODataModel.createEntry("/GETApplicationFundingSet", {
				properties: row
			});
			this._aContexts.push(oContext);

			sap.ui.core.BusyIndicator.show(0);
			if (this._oODataModel.hasPendingChanges()) {
				this._oODataModel.submitChanges({
					success: function() {
						this._oODataModel.resetChanges();
						MessageBox.success("Application successfully submited", {
							icon: sap.m.MessageBox.Icon.CONFIRMATION,
							title: "Confirmation",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function(oAction) {
								//Get Application Data
								this.getApplicationData();
							}.bind(this)
						});

					}.bind(this),
					error: function(oError) {
						this._oODataModel.resetChanges();
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error occured when submiting Application");
					}.bind(this)
				});

			} else {
				sap.ui.core.BusyIndicator.hide();
				MessageBox.error("No changes made to the Application");
			}
		},

		handleIconTabBarSelect: function(oEvent) {
			var sKey = oEvent.getParameter("key");

			if (sKey === "attachments") {
				this.byId("btnSubmit").setVisible(true);
			} else {
				this.byId("btnSubmit").setVisible(false);
			}
		},

		onValueHelpRequest: function(oEvent) {

			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment("gdsd.FundingApplication.view.fragments.Objectives", this);
				this.getView().addDependent(this._oValueHelpDialog);
				this._oValueHelpDialog.open();
			} else {
				this._oValueHelpDialog.open();
			}
		},

		onValueHelpSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("ExternalId", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onValueHelpClose: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("Objective").setValue(oSelectedItem.getTitle());
		}

	});
});