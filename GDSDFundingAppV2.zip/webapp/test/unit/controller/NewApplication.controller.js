/*global QUnit*/

sap.ui.define([
	"gdsd/FundingApplication/controller/NewApplication.controller"
], function (Controller) {
	"use strict";

	QUnit.module("NewApplication Controller");

	QUnit.test("I should test the NewApplication controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});